import logging

import typer

import pytoolkit.scripts.ghi.release

cmd = typer.Typer(help='A Wrapper for github cli.')
cmd.add_typer(pytoolkit.scripts.ghi.release.cmd, name='release')

logger = logging.getLogger()


def main():
    cmd()


if __name__ == '__main__':
    main()
